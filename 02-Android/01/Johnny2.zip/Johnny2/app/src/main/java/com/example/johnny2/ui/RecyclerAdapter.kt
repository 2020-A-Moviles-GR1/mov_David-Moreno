package com.example.johnny2.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.recyclerview.widget.RecyclerView
import com.example.johnny2.R
import com.example.johnny2.ui.base.BaseViewHolder
import com.example.johnny2.ui.producto.Producto
import kotlinx.android.synthetic.main.fragment_factura.view.*
import androidx.recyclerview.widget.RecyclerView

class RecyclerAdapter(private val listaPorducto:List<Producto>,
                      private val recyclerView:RecyclerView):androidx.recyclerview.widget.RecyclerView.Adapter<A>{


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {
        return ProductoViewHolder(LayoutInflater.from(context).inflate(R.layout.fragment_factura,parent,false))
    }

    override fun getItemCount(): Int {
       return listaPorducto.size
    }

    override fun onBindViewHolder(holder: BaseViewHolder<*>, position: Int) {
        TODO("Not yet implemented")
    }


    inner class ProductoViewHolder(itemView: View):BaseViewHolder<Producto>(itemView){
        override fun bind(item: Producto, position: Int) {
            itemView.txtProductoFactura6.text=item.marca


        }
    }

}