package com.example.johnny2.ui.producto

data class Producto(val codProducto:String, val nombre:String, val precioProveedor:Double, val precioPublico:Double,val marca: String, val cantidad:Int)





