package com.example.johnny2.ui.agregar_usuario

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.johnny2.R

class AgregarUsuarioActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agregar_usuario)
    }
}