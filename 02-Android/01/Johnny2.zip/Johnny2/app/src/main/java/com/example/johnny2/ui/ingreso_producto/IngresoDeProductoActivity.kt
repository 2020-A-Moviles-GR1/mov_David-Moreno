package com.example.johnny2.ui.ingreso_producto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.johnny2.R

class IngresoDeProductoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ingreso_de_producto)
    }
}